package com.example.qrcode.camera;

/**
 * Created by yangyu on 17/10/18.
 */

enum CameraFacing {

    BACK,  // must be value 0!
    FRONT, // must be value 1!

}

