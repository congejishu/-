package com.joe.camera2recorddemo.OpenGL.Filter;

import android.content.res.Resources;

/**
 * Created by Administrator on 2017/11/16.
 */

public class DrawFilter extends Filter {
	public DrawFilter(Resources resource) {
		super(resource, "", "");
	}
}
